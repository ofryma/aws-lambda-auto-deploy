
def lambda_handler(event , context):
    print("hello world!")
    print("hello world!")
    print("hello world!")
    return